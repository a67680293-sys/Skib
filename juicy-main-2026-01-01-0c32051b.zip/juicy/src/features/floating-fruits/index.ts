// Components
export { FloatingFruits, FruitElement } from "./components";

// Utils
export { getFruitImagePath, getFruitConfigs, fruitTypeMap, calculateAdjustedPosition } from "./utils";

// Types
export type * from "./types";
