export { default as FloatingFruits } from "./FloatingFruits";
export { FruitElement } from "./FruitElement";
